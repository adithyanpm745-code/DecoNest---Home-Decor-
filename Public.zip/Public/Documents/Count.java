/*program to read a number count the number of digits and find the sum of digits*/
import java.io.DataInputStream;
class Count{
public static void main(String args[]){
try{
int sum=0,rem=0,count=0;
DataInputStream in=new DataInputStream(System.in);
System.out.println("Enter a number:");
int n=Integer.parseInt(in.readLine());
while(n>0){
rem=n%10;
sum=sum+rem;
n=n/10;
count++;
}
System.out.println("Count="+count);
System.out.println("Sum="+sum);
}catch(Exception e){}
}
}
