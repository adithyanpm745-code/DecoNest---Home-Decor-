import java.io.DataInputStream;
class IllegalArgumentException extends Exception{
public IllegalArgumentException(){
super();}}
class ArgException{
static void readData(int a) throws IllegalArgumentException{
try{
if(a==0)
throw new IllegalArgumentException();
}catch(IllegalArgumentException e){
System.out.println("Numbers entered is zero");
System.exit(0);
}
}
public static void main(String args[]){
try{
DataInputStream in=new DataInputStream(System.in);
System.out.println("Enter first numbers");
int a=Integer.parseInt(in.readLine());
readData(a);
System.out.println("Enter second numbers");
int b=Integer.parseInt(in.readLine());
readData(b);
int product=1;
product=a*b;
System.out.println("Product is"+product);
}catch(Exception e){}
}}
