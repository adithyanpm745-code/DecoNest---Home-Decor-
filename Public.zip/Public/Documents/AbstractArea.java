import java.io.DataInputStream;
abstract class Figure{
float length,breadth,height;
abstract double area();
void getRecData(float x,float y){
length=x;
breadth=y;}
void getTriData(float x,float y){
breadth=x;
height=y;}
void PutRecData(){
System.out.println("rectangle length="+length);
System.out.println("rectangle breadth="+breadth);
}
void PutTriData(){
System.out.println("triangle breadth="+breadth);
System.out.println("triangle height="+height);
}
}
class Rectangle extends Figure{
double area(){
return length*breadth;}}
class Triangle extends Figure{
double area(){
return 0.5*(breadth*height);}
}
class AbstractArea{
public static void main(String args[]){
try{
DataInputStream in=new DataInputStream(System.in);
Rectangle r=new Rectangle();
Triangle t=new Triangle();
System.out.println("Enter length and breadth of rectangle");
float l=Float.parseFloat(in.readLine());
float b=Float.parseFloat(in.readLine());
r.getRecData(l,b);
System.out.println("Enter breadth and height of triangle");
float m=Float.parseFloat(in.readLine());
float n=Float.parseFloat(in.readLine());
t.getTriData(m,n);
r.PutRecData();
System.out.println("Area of rectangle"+r.area());
t.PutTriData();
System.out.println("Area of triangle"+t.area());
}catch(Exception e){}
}
}
