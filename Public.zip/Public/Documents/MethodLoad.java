import java.io.DataInputStream;
class RectangleArea{
int length,breadth;
void getData(int length,int breadth)
{ this.length=length;
this.breadth=breadth;
}
void getData(int length){
this.length=length;
}
int area(int l){
return l*l;
}
int area(int l,int b){
return l*b;
}
}
class MethodLoad{
public static void main(String args[]){
try{
DataInputStream in=new DataInputStream(System.in);
RectangleArea ra= new RectangleArea();
int ch=0;
do{
System.out.println("1.Rectangle");
System.out.println("2.Square");
System.out.println("3.Exit");
System.out.println("4.Enter your choice");
ch=Integer.parseInt(in.readLine());
switch(ch)
{
case 1: {System.out.println("Enter the length of Rectangle:");
int l=Integer.parseInt(in.readLine());
System.out.println("Enter the breadth of Rectangle:");
int b=Integer.parseInt(in.readLine());
ra.getData(l,b);
int a=ra.area(l,b);
System.out.println("Area of Rectangle:"+a);
break;
}
case 2: {System.out.println("Enter the side of square:");
int l=Integer.parseInt(in.readLine());
ra.getData(l);
int a=ra.area(l);
System.out.println("Area of square:"+a);
break;}
case 3:
break;
default:{
System.out.println("Invalid choice!");
break;
}
}
}
while(ch!=3);
}catch(Exception s){}
}
}

