/*draw a circle*/
import java.awt.*;
import java.applet.*;
public class Olympic extends Applet{
public void paint(Graphics g)
{
g.setColor(Color.blue);
g.drawOval(100,100,60,60);
g.setColor(Color.yellow);
g.drawOval(135,125,60,60);
g.setColor(Color.black);
g.drawOval(170,100,60,60);
g.setColor(Color.green);
g.drawOval(205,125,60,60);
g.setColor(Color.red);
g.drawOval(240,100,60,60);
}
}
