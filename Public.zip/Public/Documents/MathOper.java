import pack.MathOperations;
import java.io.DataInputStream;
class MathOper{
public static void main(String args[]){
int ch=0;
try{
DataInputStream in=new DataInputStream(System.in);
MathOperations obj=new MathOperations();
do{
System.out.println("1.Addition");
System.out.println("2.Subtraction");
System.out.println("3.Multiplication");
System.out.println("4.Division");
System.out.println("5.Modulus");
System.out.println("6.Exit");
System.out.println("Enter your choice:");
ch=Integer.parseInt(in.readLine());
switch(ch)
{
case 1:{System.out.println("Enter the  first value:");
int a=Integer.parseInt(in.readLine());
System.out.println("Enter the second value:");
int b=Integer.parseInt(in.readLine());
System.out.println("Sum of "+a+ "and" +b+ "="+obj.add(a,b));
break;}
case 2:{System.out.println("Enter the  first value:");
int a=Integer.parseInt(in.readLine());
System.out.println("Enter the second value:");
int b=Integer.parseInt(in.readLine());
System.out.println("difference of "+a+ "and" +b+ "="+obj.sub(a,b));
break;
}
case 3:{System.out.println("Enter the  first value:");
int a=Integer.parseInt(in.readLine());
System.out.println("Enter the second value:");
int b=Integer.parseInt(in.readLine());
System.out.println("Mul of "+a+ "and" +b+ "="+obj.mul(a,b));
break;
}
case 4:{System.out.println("Enter the  first value:");
int a=Integer.parseInt(in.readLine());
System.out.println("Enter the second value:");
int b=Integer.parseInt(in.readLine());
System.out.println("Division of "+a+ "and" +b+ "="+obj.div(a,b));
break;
}
case 5:{System.out.println("Enter the  first value:");
int a=Integer.parseInt(in.readLine());
System.out.println("Enter the second value:");
int b=Integer.parseInt(in.readLine());
System.out.println("Modulus of "+a+ "and" +b+ "="+obj.mod(a,b));
break;
}
case 6:{ System.out.println("Exiting");
break;
}
default:{System.out.println("Invalid choice");
break;}
}
}while(ch!=6);
}catch(Exception e){}
}
}
