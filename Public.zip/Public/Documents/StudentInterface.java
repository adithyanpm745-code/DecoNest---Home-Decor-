import java.io.DataInputStream;
class Student{
int rollno;
void getRollno(int x){
rollno=x;
}
void putRollno(){
System.out.println("Rollno:"+rollno);
}}
class Test extends Student{
int mark1,mark2;
void getMarks(int x,int y){
mark1=x;
mark2=y;
}
void putMarks()
{
System.out.println("Mark1:"+mark1);
System.out.println("Mark2:"+mark2);
}
}
interface Sports{
final float spmark=6.5f;
void putSportsMarks();
}
class Score extends Test implements Sports{
public void putSportsMarks(){
System.out.println("Sports Marks:"+spmark);
}
void putTotalMarks(){
float total=mark1+mark2+spmark;
System.out.println("Total marks:"+total);
}}
class StudentInterface{
public static void main(String args[])
{
try{
DataInputStream in=new DataInputStream(System.in);
Score s=new Score();
System.out.println("Enter roll no:");
int r=Integer.parseInt(in.readLine());
s.getRollno(r);
System.out.println("Enter mark1:");
int m1=Integer.parseInt(in.readLine());
System.out.println("Enter mark2:");
int m2=Integer.parseInt(in.readLine());
s.getMarks(m1,m2);
s.putRollno();
s.putMarks();
s.putSportsMarks();
s.putTotalMarks();
}
catch(Exception e){}
}
}
