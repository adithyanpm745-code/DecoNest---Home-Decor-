import java.io.DataInputStream;
class Student
{
int rollno;
String name;
float attendance;
void readValue(int r,String n,float a){
rollno=r;
name=n;
attendance=a;
}
void getValue()
{
System.out.println("Roll no:"+rollno);
System.out.println("Name:"+name);
System.out.println("Attendance:"+attendance);
}
}
interface Department{
final String course="S5BCA";
void getCourse();
}
class Exam extends Student implements Department{
int amark;
public void getCourse()
{
System.out.println("Course:"+course);
}
int calcAttendance()
{
if(attendance>=90){
amark=5;
}
else if(attendance>=80){
amark=4;
}
else if(attendance>=70){
amark=3;
}
else if(attendance>=60){
amark=2;
}
else if(attendance>=50){
amark=1;
}
else{
amark=0;
}
return amark;
}
void boolEligible(int amark){
if(amark>=1)
{
System.out.println("Eligible for exam");
}
else
System.out.println("Not eligible for exam");
}
}
class StudentEligible{
public static void main(String args[])
{
try{
DataInputStream in=new DataInputStream(System.in);
Exam obj=new Exam();
System.out.println("Enter rollno");
int r=Integer.parseInt(in.readLine());
System.out.println("Enter Name");
String n=in.readLine();
System.out.println("Enter attendance percentage");
float a=Float.parseFloat(in.readLine());
obj.readValue(r,n,a);
int atmark=obj.calcAttendance();
obj.getValue();
obj.getCourse();
obj.boolEligible(atmark);
}catch(Exception e){}
}
}
