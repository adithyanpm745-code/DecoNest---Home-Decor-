import java.io.DataInputStream;
import pack.Prime;
class DiagonalPrime{
public static void main(String args[]){
int a[][]={};
int sum=0;
try{
DataInputStream in=new DataInputStream(System.in);
Prime p=new Prime();
System.out.println("Enter the order of the matrix:");
int n=Integer.parseInt(in.readLine());
a=new int[n][n];
System.out.println("Enter the matrix elements:");
for(int i=0;i<n;i++)
{for(int j=0;j<n;j++)
{
a[i][j]=Integer.parseInt(in.readLine());
}}

System.out.println("The matrix is :");
for(int i=0;i<a.length;i++)
{
for(int j=0;j<a.length;j++){
System.out.print(a[i][j]+" ");
}
System.out.println();
}


for(int i=0;i<n;i++){
sum=sum+a[i][i];
}

int f1=p.primeCheck(sum);
if(f1==0)
System.out.println("Sum of diagonals"+sum+" is a prime number");
if(f1==1)
System.out.println("Sum of diagonals"+sum+" is not a prime number");
}catch(Exception e){}}
}
