/* program to find the sum of 2 numbers*/
class SumOfTwo {
public static void main(String args[]) {
int a=Integer.parseInt(args[0]);
int b=Integer.parseInt(args[1]);
System.out.println("Sum="+(a+b));
}
}
