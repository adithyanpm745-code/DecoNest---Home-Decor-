import java.io.DataInputStream;
import pack.Prime;
class MirrorPrime{
public static void main(String args[]){
try{
DataInputStream in=new DataInputStream(System.in);
Prime p=new Prime();
System.out.println("Enter a number:");
int n=Integer.parseInt(in.readLine());
int n1=n;
int f1,f2=0;
f1=p.primeCheck(n);
int reverse=0;
if(f1==0){
while(n!=0)
{ 
int d=n%10;
reverse=reverse *10+d;
n=n/10;
f2=p.primeCheck(reverse);
if(f1==1)
break;}}
if(f1==0 && f2==1)
System.out.println(n1+"is prime but the reversed number is not a prime");
if(f1==0 && f2==0)
System.out.println(n1+" is prime and its reversed number is also a prime"); 
}catch(Exception e){}
}
}
