import java.io.DataInputStream;
class Student{
int rollno;
void getRoll(int r){
rollno=r;
}
void putRoll()
{
System.out.println("Rollno=+rollno);
}
}
class Test extends Student{
int mark1,mark2;
void getMarks(int m1,int m2){
mark1=m1;
mark2=m2;
}
void putMarks()
{
System.out.println("Mark 1:"+mark1);
System.out.println("Mark 2:"+mark2);
}
}
class Score extends Test{
smark=mark1+mark2;
void putScore(){
System.out.println("Score="+smark);
}
}
interface Sports
{
float spmark;
void getSpmark(int s){
spmark=s;
}
void putSpmark()
{
System.out.println("Sports mark="+spmark); 
}
}

