/*prgm to read n numbers and race an exception called NegativeException when a negtive number is entered*/
import java.io.DataInputStream;
class NegativeException extends Exception{
public NegativeException(){
super();
}}
class ExNegative{
static void readData(int a) throws NegativeException{
try{
if(a<0)
throw new NegativeException();
}catch(NegativeException ne){
System.out.println("Entered a negative number");
System.exit(0);
}}
public static void main(String args[]){
try{
DataInputStream in=new DataInputStream(System.in);
System.out.println("Enter N:");
int n=Integer.parseInt(in.readLine());
System.out.println("Enter n numbers:");
for(int i=0;i<n;i++){
int a=Integer.parseInt(in.readLine());
readData(a);
}
}catch(Exception e){}
}}
