import java.io.DataInputStream;
class Base{
int rollno;
Base(int x){
rollno=x;
}
}
class Child extends Base{
int mark1,mark2,total;
Child(int x,int m1,int m2){
super(x);
mark1=m1;
mark2=m2;
}
void display()
{
total=mark1+mark2;
System.out.println("rollno="+rollno);
System.out.println("Mark1="+mark1);
System.out.println("Mark2="+mark2);
System.out.println("Total mark="+total);
}
}
class SingleSuper{
public static void main(String args[])
{
try{
DataInputStream in=new DataInputStream(System.in);
System.out.println("Enter roll no:");
int x=Integer.parseInt(in.readLine());
System.out.println("Enter mark1:");
int y=Integer.parseInt(in.readLine());
System.out.println("Enter mark2:");
int z=Integer.parseInt(in.readLine());
Child c=new Child(x,y,z);
c.display();
}catch(Exception e){}
}
}

