package pack;
public class FactorialFact{
int f;
public int factorial(int x){
f=1;
for(int i=1;i<=x;i++)
f=f*i;
return(f);
}
}
