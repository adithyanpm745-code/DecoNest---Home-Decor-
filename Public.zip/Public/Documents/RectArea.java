/*program to find area and perimeter using classes and objects*/
import java.io.DataInputStream;
class Rectangle{
int length,breadth;
void getData(int x,int y){
length=x;
breadth=y;
}
int area()
{
return length*breadth;
}
int peri(){
return 2*(length+breadth);
}
}
class RectArea{
public static void main(String args[]){
try{
DataInputStream in=new DataInputStream(System.in);
Rectangle r=new Rectangle();
System.out.println("Enter the length of rectangle:");
int l=Integer.parseInt(in.readLine());
System.out.println("Enter the breadth of rectangle:");
int b=Integer.parseInt(in.readLine());
r.getData(l,b);
System.out.println("Area of rectangle is " +r.area());
System.out.println("Perimeter is " +r.peri());
}catch(Exception e){}
}
}


