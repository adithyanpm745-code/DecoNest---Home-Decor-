class Parent{
void display(){
System.out.println("This is a parent class method");
}
}
class Child{
void display(){
System.out.println("This is child class method");
}
}
class MethodOverRide{
public static void main(String args[])
{
Child c=new Child();
c.display();
}
}
