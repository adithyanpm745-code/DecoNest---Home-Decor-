import java.applet.*;
import java.awt.*;
public class Star extends Applet{
public void paint(Graphics g)
{
g.drawLine(100,125,300,125);
g.drawLine(100,200,300,125);
g.drawLine(100,125,300,200);
g.drawLine(100,200,200,75);
g.drawLine(300,200,200,75);
}
}
