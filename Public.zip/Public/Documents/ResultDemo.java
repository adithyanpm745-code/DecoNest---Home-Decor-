import java.io.DataInputStream;
class MarksOutOfBoundsException extends Exception{
public MarksOutOfBoundsException(){
super();}}
class ResultDemo{
static void read(int a) throws MarksOutOfBoundsException{
try{
if(a<0||a>100)
throw new MarksOutOfBoundsException();
}catch(MarksOutOfBoundsException e){
System.out.println("Invalid mark");
System.exit(0);
}}
public static void main(String args[]){
try{
DataInputStream in=new DataInputStream(System.in);
int m[]=new int[3];
int total=0;
System.out.println("Enter name:");
String s=in.readLine();
System.out.println("Enter regno:");
int b=Integer.parseInt(in.readLine());
System.out.println("Enter date:");
String s1=in.readLine();
System.out.println("Enter marks:");
for(int i=0;i<3;i++){
m[i]=Integer.parseInt(in.readLine());
read(m[i]);
total=total+m[i];
}
System.out.println();
System.out.println("RESULT");
System.out.println("Name:"+s);
System.out.println("Regno:"+b);
System.out.println("Date:"+s1);
System.out.println("Marks:");
for(int i=0;i<3;i++)
System.out.println(m[i]);
System.out.println("Total marks:"+total);
}catch(Exception e){}
}
}
