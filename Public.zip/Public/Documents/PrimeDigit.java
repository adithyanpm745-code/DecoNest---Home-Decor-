import java.io.DataInputStream;
import pack.Prime;
class PrimeDigit{
public static void main(String args[]){
try{
DataInputStream in=new DataInputStream(System.in);
Prime p=new Prime();
System.out.println("Enter a number:");
int n=Integer.parseInt(in.readLine());
int n1=n;
int f1,f2=0;
f1=p.primeCheck(n);
if(f1==0){
while(n!=0){
int r=n%10;
n=n/10;
f2=p.primeCheck(n);
if(f2==1)
break;
}}
if(f1==1){
System.out.println(n1+"is not prime");
}
if(f1==0 && f2==1)
System.out.println(n1+" is prime but digits are not prime");
if(f1==0 && f2==0)
System.out.println(n1+" is prime and digits are also prime");
}catch(Exception e){}
}}
