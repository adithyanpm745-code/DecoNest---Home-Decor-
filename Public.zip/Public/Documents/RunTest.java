class X implements Runnable{
public void run(){
for(int i=1;i<=5;i++)
System.out.println("Thread X:"+i);
System.out.println("End of thread x");}}
class RunTest{
public static void main(String args[]){
X runX=new X();
Thread ThreadX=new Thread(runX);
ThreadX.start();
}}
