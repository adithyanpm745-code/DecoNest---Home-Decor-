/*program to find the roots of a quadratic equation*/
import java.io.DataInputStream;
class Root{
public static void main(String args[]){
try{
DataInputStream in =new DataInputStream(System.in);
System.out.println("Enter the coefficient of a:");
int a=Integer.parseInt(in.readLine());
System.out.println("Enter the coefficient of b:");
int b=Integer.parseInt(in.readLine());
System.out.println("Enter the coefficient of c:");
int c=Integer.parseInt(in.readLine());
double d=b*b-4*a*c;
if(d==0){
System.out.println("Roots are real and equal");
double r1=-b/(2*a);
System.out.println("Root1=Root2="+r1);
}
else if(d>0){
System.out.println("Roots area real and different");
double r1=-b+Math.sqrt(d)/(2*a);
double r2=-b-Math.sqrt(d)/(2*a);
System.out.println("Root1="+r1);
System.out.println("Root2="+r2);
}
else{
System.out.println("Roots are different and imaginary");
double realPart=-b/(2.0*a);
double imgPart=Math.sqrt(-d)/(2*a);
System.out.println("Root1="+realPart+"+i"+imgPart);
System.out.println("Root2="+realPart+"-i"+imgPart);
}
}catch(Exception e){}
}
}
