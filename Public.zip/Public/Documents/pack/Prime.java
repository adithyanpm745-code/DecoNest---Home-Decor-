package pack;
public class Prime{
int flag=0;
public int primeCheck(int k){
for(int i=2;i<=(int)Math.sqrt(k);i++)
{if(k%i==0)
{
flag=1;
break;
}
}
return(flag);
}
}
