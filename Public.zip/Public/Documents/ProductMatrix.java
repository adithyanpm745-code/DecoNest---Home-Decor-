import java.io.DataInputStream;
class ProductMatrix{
static int[][] read(){
int a[][]={};
try{
DataInputStream in= new DataInputStream(System.in);
System.out.println("Enter number of row:");
int r= Integer.parseInt(in.readLine());
System.out.println("Enter number of column:");
int c =Integer.parseInt(in.readLine());
a=new int[r][c];
System.out.println("Enter the elements:");
for(int i=0;i<r;i++){
for(int j=0;j<c;j++){
a[i][j]=Integer.parseInt(in.readLine());}}
}catch(Exception e){}
return a;}
static void print(int[][] a){
for(int i=0;i<a.length;i++){
for(int j=0;j<a[0].length;j++){
System.out.print(a[i][j]+" ");
}
System.out.println();
}
}
static int[][] product(int[][] a,int [][] b){
if(a[0].length!=b.length){
System.out.println("Matrix multiplication not possible");
return null;
}
int s[][]=new int[a.length][b[0].length];
for(int i=0;i<a.length;i++){
for(int j=0;j<b[0].length;j++){
s[i][j]=0;
for(int k=0;k<a[0].length;k++){
s[i][j]+=a[i][k]*b[k][j];}}}
return s;}
static int[][] scalar(int[][] a)
{
int p[][]={};
try{
DataInputStream in=new DataInputStream(System.in);
System.out.println("enter the element to be multiplied for scalar");
int n=Integer.parseInt(in.readLine());
p=new int[a.length][a[0].length];
for(int i=0;i<a.length;i++){
for(int j=0;j<a[0].length;j++){
p[i][j]=n*a[i][j];
}
}
}catch(Exception e){}
return p;
}
public static void main(String args[]){
System.out.println("first matrix:");
int a[][]=read();
System.out.println("second matrix:");
int b[][]=read();
System.out.println("first matrix:");
System.out.println();
print(a);
System.out.println("second matrix:");
System.out.println();
print(b);
int p[][]=product(a,b);
int s[][]=scalar(a);
if(p!=null){
System.out.println("Result matrix");
System.out.println();
print(p);
}
System.out.println("scalar matrix");
System.out.println();
print(s);
}
}

