class MultipleCatchDemo{
public static void main(String args[]){
int a[]={5,10};
int b=5;
int x;
try{
x=a[1]/(b-a[0]);
}
catch(ArithmeticException e)
{
System.out.println(e);
System.out.println("Division by zero occured");
}
catch(ArrayIndexOutOfBoundsException e)
{
System.out.println(e);
System.out.println("Array Index Error");
}
catch(ArrayStoreException e)
{
System.out.println(e);
System.out.println("wrong data type");
}
System.out.println("End of program");
}
}
