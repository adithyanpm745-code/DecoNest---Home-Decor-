import java.io.DataInputStream;
class AgeNotWithinRangeException extends Exception{
public AgeNotWithinRangeException(){
super();}}
class NameNotValidException extends Exception{
public NameNotValidException(){
super();}}
class Student{
static void readAge(int a) throws AgeNotWithinRangeException{
try{
if(a<15||a>21)
throw new AgeNotWithinRangeException();
}catch(AgeNotWithinRangeException ae)
{
System.out.println("Age not valid");
System.exit(0);}
}
static void readName(String n) throws NameNotValidException{
try{
for(int i=0;i<=n.length();i++){
if(Character.isLetter(n.charAt(i))==false){
throw new NameNotValidException();}
}
}catch(NameNotValidException ne){
System.out.println("Name is not valid");
System.exit(0);
}
}
static void display(int r,String n,int a,String c){
System.out.println("STUDENT DETAILS");
System.out.println("Roll:"+r);
System.out.println("Name:"+n);
System.out.println("Age:"+a);
System.out.println("Course:"+c);
}
public static void main(String args[])
{
try{
DataInputStream in=new DataInputStream(System.in);
System.out.println("Enter roll no:");
int r=Integer.parseInt(in.readLine());
System.out.println("Enter name:");
String n=in.readLine();
readName(n);
System.out.println("Enter age:");
int a=Integer.parseInt(in.readLine());
readAge(a);
System.out.println("Enter course:");
String c=in.readLine();
display(r,n,a,c);
}catch(Exception e){}
}
}
