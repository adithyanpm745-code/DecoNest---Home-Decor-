<?php
include("../Assets/Connection/Connection.php");
session_start();

// Fetch dashboard statistics from database
$userCountQuery = "SELECT COUNT(*) as total_users FROM tbl_user";
$userCountResult = mysqli_query($con, $userCountQuery);
$userCount = mysqli_fetch_array($userCountResult)['total_users'];

$sellerCountQuery = "SELECT COUNT(*) as total_sellers FROM tbl_seller WHERE seller_status = '1'";
$sellerCountResult = mysqli_query($con, $sellerCountQuery);
$sellerCount = mysqli_fetch_array($sellerCountResult)['total_sellers'];

$totalSalesQuery = "SELECT SUM(booking_amount) as total_sales FROM tbl_booking WHERE booking_status IN ('3', '4', '5')";
$totalSalesResult = mysqli_query($con, $totalSalesQuery);
$totalSales = mysqli_fetch_array($totalSalesResult)['total_sales'] ?? 0;

$orderCountQuery = "SELECT COUNT(*) as total_orders FROM tbl_booking";
$orderCountResult = mysqli_query($con, $orderCountQuery);
$orderCount = mysqli_fetch_array($orderCountResult)['total_orders'];

// Recent bookings for reports
$recentBookingsQuery = "SELECT b.*, u.user_name, u.user_email FROM tbl_booking b 
                       INNER JOIN tbl_user u ON b.user_id = u.user_id 
                       ORDER BY b.booking_id DESC LIMIT 5";
$recentBookingsResult = mysqli_query($con, $recentBookingsQuery);

// Complaint count
$complaintCountQuery = "SELECT COUNT(*) as total_complaints FROM tbl_complaint WHERE complaint_status = '0'";
$complaintCountResult = mysqli_query($con, $complaintCountQuery);
$pendingComplaints = mysqli_fetch_array($complaintCountResult)['total_complaints'];

// Top selling products
$topProductsQuery = "SELECT p.product_name, SUM(c.cart_quantity) as total_sold 
                    FROM tbl_cart c 
                    INNER JOIN tbl_product p ON c.product_id = p.product_id 
                    WHERE c.cart_status = '1'
                    GROUP BY p.product_id, p.product_name 
                    ORDER BY total_sold DESC LIMIT 5";
$topProductsResult = mysqli_query($con, $topProductsQuery);

// Monthly sales data for chart
$monthlySalesQuery = "SELECT 
    MONTH(booking_date) as month,
    YEAR(booking_date) as year,
    SUM(booking_amount) as monthly_total
    FROM tbl_booking 
    WHERE booking_status IN ('3', '4', '5') 
    AND YEAR(booking_date) = YEAR(CURDATE())
    GROUP BY MONTH(booking_date), YEAR(booking_date) 
    ORDER BY month";
$monthlySalesResult = mysqli_query($con, $monthlySalesQuery);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>DecoNest - Admin Dashboard</title>
    <meta
      content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
      name="viewport"
    />
    <link
      rel="icon"
      href="../Assets/Templates/Admin/assets/img/kaiadmin/favicon.ico"
      type="image/x-icon"
    />

    <!-- Fonts and icons -->
    <script src="../Assets/Templates/Admin/assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
      WebFont.load({
        google: { families: ["Public Sans:300,400,500,600,700"] },
        custom: {
          families: [
            "Font Awesome 5 Solid",
            "Font Awesome 5 Regular",
            "Font Awesome 5 Brands",
            "simple-line-icons",
          ],
          urls: ["../Assets/Templates/Admin/assets/css/fonts.min.css"],
        },
        active: function () {
          sessionStorage.fonts = true;
        },
      });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="../Assets/Templates/Admin/assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../Assets/Templates/Admin/assets/css/plugins.min.css" />
    <link rel="stylesheet" href="../Assets/Templates/Admin/assets/css/kaiadmin.min.css" />
    <link rel="stylesheet" href="../Assets/Templates/Admin/assets/css/demo.css" />
  </head>
  <body>
    <div class="wrapper">
      <!-- Sidebar -->
      <div class="sidebar" data-background-color="dark">
        <div class="sidebar-logo">
          <div class="logo-header" data-background-color="dark">
            <a href="HomePage.php" class="logo">
              <img
                src="../Assets/Templates/Admin/assets/img/kaiadmin/DecoNest.png" height="150" weight="250"
                alt="navbar brand"
                class="navbar-brand"
                height="20"
              />
            </a>
            <div class="nav-toggle">
              <button class="btn btn-toggle toggle-sidebar">
                <i class="gg-menu-right"></i>
              </button>
              <button class="btn btn-toggle sidenav-toggler">
                <i class="gg-menu-left"></i>
              </button>
            </div>
            <button class="topbar-toggler more">
              <i class="gg-more-vertical-alt"></i>
            </button>
          </div>
        </div>
        <div class="sidebar-wrapper scrollbar scrollbar-inner">
          <div class="sidebar-content">
            <ul class="nav nav-secondary">
              <li class="nav-item active">
                <a
                  data-bs-toggle="collapse"
                  href="#dashboard"
                  class="collapsed"
                  aria-expanded="false">
                  <i class="fas fa-home"></i>
                  <p>Dashboard</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="dashboard">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="HomePage.php">
                        <span class="sub-item">Dashboard 1</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-section">
                <span class="sidebar-mini-icon">
                  <i class="fa fa-ellipsis-h"></i>
                </span>
                <h4 class="text-section">Pages</h4>
              </li>
              <li class="nav-item">
                <a data-bs-toggle="collapse" href="#base">
                <i class="fas fa-map-marker-alt"></i> 
                  <p>Location</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="base">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="District.php">
                        <span class="sub-item">District</span>
                      </a>
                    </li>
                    <li>
                      <a href="Place.php">
                        <span class="sub-item">Place</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li class="nav-item">
                <a data-bs-toggle="collapse" href="#sidebarLayouts">
                  <i class="fas fa-layer-group"></i>
                  <p>Category</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="sidebarLayouts">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="Category.php">
                        <span class="sub-item">Category</span>
                      </a>
                    </li>
                    <li>
                      <a href="SubCategory.php">
                        <span class="sub-item">Sub Category</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>

              <li class="nav-item">
                <a data-bs-toggle="collapse" href="#tables">
                  <i class="fas fa-palette"></i>
                  <p>Colour & Material</p>
                  <span class="caret"></span>
                </a>
                <div class="collapse" id="tables">
                  <ul class="nav nav-collapse">
                    <li>
                      <a href="Colour.php">
                        <span class="sub-item">Colour</span>
                      </a>
                    </li>
                    <li>
                      <a href="Material.php">
                        <span class="sub-item">Material</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>

              <li class="nav-section">
                <span class="sidebar-mini-icon">
                  <i class="fas fa-ellipsis-h"></i>
                </span>
                <h4 class="text-section">User & Seller List</h4>
              </li>

              <li class="nav-item">
                <a href="SellerList.php">
                  <i class="fas fa-user-tie"></i>
                  <p>Seller List</p>
                </a>
              </li>
               <li class="nav-item">
                <a href="UserList.php">
                  <i class="fas fa-users"></i>
                  <p>User List</p>
                </a>
              </li>

              <li class="nav-section">
                <span class="sidebar-mini-icon">
                  <i class="fa fa-ellipsis-h"></i>
                </span>
                <h4 class="text-section">Complaints & FeedBacks</h4>
              </li>

              <li class="nav-item">
                <a href="ViewComplaint.php">
                  <i class="fas fa-comment-dots"></i>
                  <p>Complaints</p>
                  <?php if($pendingComplaints > 0): ?>
                  <span class="badge badge-danger"><?php echo $pendingComplaints; ?></span>
                  <?php endif; ?>
                </a>
              </li>
               <li class="nav-item">
                <a href="ViewFeedBack.php">
                  <i class="fas fa-comments"></i>
                  <p>FeedBacks</p>
                </a>
              </li>

              <li class="nav-section">
                <span class="sidebar-mini-icon">
                  <i class="fa fa-ellipsis-h"></i>
                </span>
                <h4 class="text-section">Reports</h4>
              </li>

              <li class="nav-item">
                <a href="Report.php">
                  <i class="fas fa-chart-bar"></i>
                  <p>Reports</p>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <!-- End Sidebar -->

      <div class="main-panel">
        <div class="main-header">
          <div class="main-header-logo">
            <div class="logo-header" data-background-color="dark">
              <a href="HomePage.php" class="logo">
                <img
                  src="../Assets/Templates/Admin/assets/img/kaiadmin/logo_light.svg"
                  alt="navbar brand"
                  class="navbar-brand"
                  height="20"
                />
              </a>
              <div class="nav-toggle">
                <button class="btn btn-toggle toggle-sidebar">
                  <i class="gg-menu-right"></i>
                </button>
                <button class="btn btn-toggle sidenav-toggler">
                  <i class="gg-menu-left"></i>
                </button>
              </div>
              <button class="topbar-toggler more">
                <i class="gg-more-vertical-alt"></i>
              </button>
            </div>
          </div>
          
          <!-- Navbar Header -->
          <nav class="navbar navbar-header navbar-header-transparent navbar-expand-lg border-bottom">
            <div class="container-fluid">
              <nav class="navbar navbar-header-left navbar-expand-lg navbar-form nav-search p-0 d-none d-lg-flex">
              </nav>

              <ul class="navbar-nav topbar-nav ms-md-auto align-items-center">
                <li class="nav-item topbar-icon dropdown hidden-caret">
                  <a class="nav-link dropdown-toggle" href="#" id="notifDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-bell"></i>
                    <?php if($pendingComplaints > 0): ?>
                    <span class="notification"><?php echo $pendingComplaints; ?></span>
                    <?php endif; ?>
                  </a>
                  <ul class="dropdown-menu notif-box animated fadeIn" aria-labelledby="notifDropdown">
                    <li>
                      <div class="dropdown-title">
                        You have <?php echo $pendingComplaints; ?> pending complaints
                      </div>
                    </li>
                    <li>
                      <a class="see-all" href="ViewComplaint.php">View all complaints<i class="fa fa-angle-right"></i></a>
                    </li>
                  </ul>
                </li>

                <li class="nav-item topbar-user dropdown hidden-caret">
                  <a class="dropdown-toggle profile-pic" data-bs-toggle="dropdown" href="#" aria-expanded="false">
                    <div class="avatar-sm">
                      <img src="../Assets/Templates/Admin/assets/img/profile.jpg" alt="..." class="avatar-img rounded-circle" />
                    </div>
                    <span class="profile-username">
                      <span class="op-7">Hi, </span>
                      <span class="fw-bold"><?php echo $_SESSION["aname"]?></span>
                    </span>
                  </a>
                  <ul class="dropdown-menu dropdown-user animated fadeIn">
                    <div class="dropdown-user-scroll scrollbar-outer">
                      <li>
                        <div class="user-box">
                          <div class="avatar-lg">
                            <img src="../Assets/Templates/Admin/assets/img/profile.jpg" alt="image profile" class="avatar-img rounded" />
                          </div>
                          <div class="u-text">
                            <h4><?php echo $_SESSION["aname"]?></h4>
                            <p class="text-muted">deconest001@gmail.com</p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="Logout.php">Logout</a>
                      </li>
                    </div>
                  </ul>
                </li>
              </ul>
            </div>
          </nav>
        </div>

        <div class="container">
          <div class="page-inner">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row pt-2 pb-4">
              <div>
                <h3 class="fw-bold mb-3">Dashboard</h3>
                <h6 class="op-7 mb-2">Welcome to DecoNest Admin Panel</h6>
              </div>
              <div class="ms-md-auto py-2 py-md-0">
                <a href="SellerList.php" class="btn btn-label-info btn-round me-2">View Sellers</a>
                <a href="Report.php" class="btn btn-primary btn-round">Reports</a>
              </div>
            </div>
            
            <!-- Statistics Cards -->
            <div class="row">
              <div class="col-sm-6 col-md-3">
                <div class="card card-stats card-round">
                  <div class="card-body">
                    <div class="row align-items-center">
                      <div class="col-icon">
                        <div class="icon-big text-center icon-primary bubble-shadow-small">
                          <i class="fas fa-users"></i>
                        </div>
                      </div>
                      <div class="col col-stats ms-3 ms-sm-0">
                        <div class="numbers">
                          <p class="card-category">Total Users</p>
                          <h4 class="card-title"><?php echo number_format($userCount); ?></h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-md-3">
                <div class="card card-stats card-round">
                  <div class="card-body">
                    <div class="row align-items-center">
                      <div class="col-icon">
                        <div class="icon-big text-center icon-info bubble-shadow-small">
                          <i class="fas fa-user-check"></i>
                        </div>
                      </div>
                      <div class="col col-stats ms-3 ms-sm-0">
                        <div class="numbers">
                          <p class="card-category">Active Sellers</p>
                          <h4 class="card-title"><?php echo number_format($sellerCount); ?></h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-md-3">
                <div class="card card-stats card-round">
                  <div class="card-body">
                    <div class="row align-items-center">
                      <div class="col-icon">
                        <div class="icon-big text-center icon-success bubble-shadow-small">
                          <i class="fas fa-rupee-sign"></i>
                        </div>
                      </div>
                      <div class="col col-stats ms-3 ms-sm-0">
                        <div class="numbers">
                          <p class="card-category">Total Sales</p>
                          <h4 class="card-title">₹ <?php echo number_format($totalSales, 2); ?></h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-md-3">
                <div class="card card-stats card-round">
                  <div class="card-body">
                    <div class="row align-items-center">
                      <div class="col-icon">
                        <div class="icon-big text-center icon-secondary bubble-shadow-small">
                          <i class="far fa-check-circle"></i>
                        </div>
                      </div>
                      <div class="col col-stats ms-3 ms-sm-0">
                        <div class="numbers">
                          <p class="card-category">Total Orders</p>
                          <h4 class="card-title"><?php echo number_format($orderCount); ?></h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Charts and Tables Row -->
            <div class="row">
              <!-- Recent Orders -->
              <div class="col-md-8">
                <div class="card card-round">
                  <div class="card-header">
                    <div class="card-head-row card-tools-still-right">
                      <h4 class="card-title">Recent Orders</h4>
                      <div class="card-tools">
                        <a href="Report.php" class="btn btn-label-info btn-round btn-sm">
                          <span class="btn-label">
                            <i class="fa fa-print"></i>
                          </span>
                          View All
                        </a>
                      </div>
                    </div>
                  </div>
                  <div class="card-body p-0">
                    <div class="table-responsive">
                      <table class="table align-items-center mb-0">
                        <thead class="thead-light">
                          <tr>
                            <th scope="col">Order ID</th>
                            <th scope="col">Customer</th>
                            <th scope="col" class="text-end">Date</th>
                            <th scope="col" class="text-end">Amount</th>
                            <th scope="col" class="text-end">Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php while($row = mysqli_fetch_array($recentBookingsResult)): ?>
                          <tr>
                            <th scope="row">#<?php echo $row['booking_id']; ?></th>
                            <td><?php echo $row['user_name']; ?></td>
                            <td class="text-end"><?php echo date('M d, Y', strtotime($row['booking_date'])); ?></td>
                            <td class="text-end">₹<?php echo number_format($row['booking_amount'], 2); ?></td>
                            <td class="text-end">
                              <?php 
                              switch($row['booking_status']) {
                                case '0': echo '<span class="badge badge-warning">Pending</span>'; break;
                                case '1': echo '<span class="badge badge-info">Confirmed</span>'; break;
                                case '2': echo '<span class="badge badge-primary">Packed</span>'; break;
                                case '3': echo '<span class="badge badge-secondary">Shipped</span>'; break;
                                case '4': echo '<span class="badge badge-success">Delivered</span>'; break;
                                case '5': echo '<span class="badge badge-success">Completed</span>'; break;
                                default: echo '<span class="badge badge-dark">Unknown</span>';
                              }
                              ?>
                            </td>
                          </tr>
                          <?php endwhile; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Top Products -->
              <div class="col-md-4">
                <div class="card card-round">
                  <div class="card-header">
                    <div class="card-head-row">
                      <div class="card-title">Top Selling Products</div>
                    </div>
                  </div>
                  <div class="card-body">
                    <div class="card-list py-4">
                      <?php while($product = mysqli_fetch_array($topProductsResult)): ?>
                      <div class="item-list">
                        <div class="info-user ms-3">
                          <div class="username"><?php echo $product['product_name']; ?></div>
                          <div class="status"><?php echo $product['total_sold']; ?> units sold</div>
                        </div>
                      </div>
                      <?php endwhile; ?>
                    </div>
                  </div>
                </div>
                
                <!-- Quick Stats -->
                <div class="card card-round">
                  <div class="card-body pb-0">
                    <div class="h1 fw-bold float-end text-primary"><?php echo $pendingComplaints; ?></div>
                    <h2 class="mb-2">Complaints</h2>
                    <p class="text-muted">Pending Resolution</p>
                    <?php if($pendingComplaints > 0): ?>
                    <a href="ViewComplaint.php" class="btn btn-sm btn-warning">View Complaints</a>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Custom template -->
      <div class="custom-template">
        <div class="title">Settings</div>
        <div class="custom-content">
          <div class="switcher">
            <div class="switch-block">
              <h4>Logo Header</h4>
              <div class="btnSwitch">
                <button type="button" class="selected changeLogoHeaderColor" data-color="dark"></button>
                <button type="button" class="changeLogoHeaderColor" data-color="blue"></button>
                <button type="button" class="changeLogoHeaderColor" data-color="purple"></button>
                <button type="button" class="changeLogoHeaderColor" data-color="light-blue"></button>
                <button type="button" class="changeLogoHeaderColor" data-color="green"></button>
                <button type="button" class="changeLogoHeaderColor" data-color="orange"></button>
                <button type="button" class="changeLogoHeaderColor" data-color="red"></button>
                <button type="button" class="changeLogoHeaderColor" data-color="white"></button>
              </div>
            </div>
            <div class="switch-block">
              <h4>Navbar Header</h4>
              <div class="btnSwitch">
                <button type="button" class="changeTopBarColor" data-color="dark"></button>
                <button type="button" class="changeTopBarColor" data-color="blue"></button>
                <button type="button" class="changeTopBarColor" data-color="purple"></button>
                <button type="button" class="changeTopBarColor" data-color="light-blue"></button>
                <button type="button" class="changeTopBarColor" data-color="green"></button>
                <button type="button" class="changeTopBarColor" data-color="orange"></button>
                <button type="button" class="changeTopBarColor" data-color="red"></button>
                <button type="button" class="selected changeTopBarColor" data-color="white"></button>
              </div>
            </div>
            <div class="switch-block">
              <h4>Sidebar</h4>
              <div class="btnSwitch">
                <button type="button" class="changeSideBarColor" data-color="white"></button>
                <button type="button" class="selected changeSideBarColor" data-color="dark"></button>
                <button type="button" class="changeSideBarColor" data-color="dark2"></button>
              </div>
            </div>
          </div>
        </div>
        <div class="custom-toggle">
          <i class="icon-settings"></i>
        </div>
      </div>
    </div>

    <!-- Core JS Files -->
    <script src="../Assets/Templates/Admin/assets/js/core/jquery-3.7.1.min.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/core/popper.min.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/core/bootstrap.min.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/plugin/chart.js/chart.min.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/plugin/chart-circle/circles.min.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/plugin/datatables/datatables.min.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/plugin/jsvectormap/jsvectormap.min.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/plugin/jsvectormap/world.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/plugin/sweetalert/sweetalert.min.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/kaiadmin.min.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/setting-demo.js"></script>
    <script src="../Assets/Templates/Admin/assets/js/demo.js"></script>
  </body>
</html>