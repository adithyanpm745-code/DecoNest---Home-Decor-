/*factorial of a number*/
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class SwingProgram extends JApplet implements ActionListener{
int num,fact;
JButton jb1;
JLabel jl1;
JTextField jtf1,jtf2;
public void init()
{
Container contentPane=getContentPane();
contentPane.setLayout(new FlowLayout());
jl1=new JLabel("Enter number:");
jtf1= new JTextField(20);
jb1=new JButton("Factorial");
jtf2=new JTextField(20);
contentPane.add(jl1);
contentPane.add(jtf1);
contentPane.add(jtf2);
contentPane.add(jb1);
jb1.addActionListener(this);
}
public void actionPerformed(ActionEvent ae)
{
num=Integer.parseInt(jtf1.getText());
fact=1;
for(int i=1;i<=num;i++)
fact*=i;
jtf2.setText(String.valueOf(fact));
}
}
