class parent{
void disp(){
System.out.println("This is a parent class method");}}
class child extends parent{
void disp(){
System.out.println("This is a child class method");}}
class MethodOverride{
public static void main(String args[]){
child obj=new child();
obj.disp();
}
}
