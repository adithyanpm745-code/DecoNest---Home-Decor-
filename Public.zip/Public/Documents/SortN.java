import java.io.DataInputStream;
class SortN{
static int[] readArray(){
int a[]={};
try{
DataInputStream in=new DataInputStream(System.in);
System.out.println("Enter the no of elements:");
int n=Integer.parseInt(in.readLine());
a=new int[n];
System.out.println("Enter the elements:");
for(int i=0;i<n;i++){
a[i]=Integer.parseInt(in.readLine());}
}catch(Exception e){}
return a;
}
static void printArray(int[] a){
System.out.println("The array is:");
for(int i=0;i<a.length;i++)
System.out.println(a[i]+" ");
}
static int[] sortArray(int[] a)
{
for(int i=0;i<a.length-1;i++){
for(int j=i+1;j<a.length;j++){
if(a[i]>a[j])
{
int t=a[i];
a[i]=a[j];
a[j]=t;
}
}}
return a;
}
public static void main(String args[])
{
int a[]=readArray();
System.out.println("original array:");
printArray(a);
int s[]=sortArray(a);
System.out.println("sorted array");
printArray(s);
}
}
