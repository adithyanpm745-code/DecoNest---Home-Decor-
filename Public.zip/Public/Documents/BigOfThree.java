/*program to find the biggest of 3 numbers*/
class BigOfThree{
public static void main(String args[]){
int a=Integer.parseInt(args[0]);
int b=Integer.parseInt(args[1]);
int c=Integer.parseInt(args[2]);
int big=a;
if b>big then big=b;
if c>big then big=c;
System.out.println("Big="+big);
}
}
