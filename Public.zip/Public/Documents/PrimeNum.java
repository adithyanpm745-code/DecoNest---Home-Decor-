/*program to find prime numbers between two limits*/
class PrimeNum{
public static void main(String args[])
{
int m=Integer.parseInt(args[0]);
int n=Integer.parseInt(args[1]);
outer:for(int i=m;i<=n;i++)
{
int k=(int)Math.sqrt(i);
inner:for(int j=2;j<=k;j++)
{
if(i%j==0) continue outer;
}
System.out.println(i);
}
}
}
