/*program to find area of rectangle and sqare using constructor overloading*/
import java.io.DataInputStream;
class Area{
int length,breadth,side;
Area(int l,int b){
l=length;
b=breadth;
}
Area(int s){
s=side;
}
int areaRect(){
return length*breadth;
}
int areaSquare(){
return side*side;
}
}
class ConstructLoad{
public static void main(String args[]){
try{
DataInputStream in=new DataInputStream(System.in);
Area a=new Area();
int ch=0;
do{
System.out.println("1.Rectangle");
System.out.println("2.Square");
System.out.println("3.Exit");
System.out.println("Enter your choice");
ch=Integer.parseInt(in.readLine());
switch(ch){
case 1:{System.out.println("Enter the length of rectangle:");
int l=Integer.parseInt(in.readLine());
System.out.println("Enter the breadth of rectangle:");
int b=Integer.parseInt(in.readLine());
int area=a.areaRect(l,b);
System.out.println("Area of rectangle="+area);
break;
}
case 2:{System.out.println("Enter the side of square:");
int s=Integer.parseInt(in.readLine());
int b=a.areaSquare(s);
System.out.println("Area of square="+b);
break;
}
case 3:
break;
default:{
System.out.println("Invalide choice");
break;
}}
}while(ch!=3);
}catch(Exception e){}
}
}
