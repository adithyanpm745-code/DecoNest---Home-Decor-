import java.io.DataInputStream;
interface Department{
final String depname="BCA";
final String dephead="Anu Paul";
void showData();
}
class Hostel{
String hostname,hostlocation;
int noofrooms;
void readData(String hn,String hl,int nr){
hostname=hn;
hostlocation=hl;
noofrooms=nr;}
void printData(){
System.out.println("hostel name:"+hostname);
System.out.println("hostel location:"+hostlocation);
System.out.println("no of rooms:"+noofrooms);
}
}
class Student extends Hostel implements Department{
String studname,elesub;
int regno,avgmark;
public void showData(){
System.out.println("Department name:"+depname);
System.out.println("Department Head:"+dephead);
}
void getData(String sname,int regnos,String cs,int avg){
studname=sname;
regno=regnos;
elesub=cs;
avgmark=avg;
}
void displayData(){
System.out.println("Student name:"+studname);
System.out.println("Student register number:"+regno);
System.out.println("Student elective sub:"+elesub);
System.out.println("Student avg mark:"+avgmark);
}
}
class DepStudent{
public static void main(String args[]){
try{
DataInputStream in =new DataInputStream(System.in);
Student s=new Student();
System.out.println("Enter student name");
String name=in.readLine();
System.out.println("Enter student register no");
int reg=Integer.parseInt(in.readLine());
System.out.println("Enter student elective sub");
String sub=in.readLine();
System.out.println("Enter student avgmark");
int avg=Integer.parseInt(in.readLine());
s.getData(name,reg,sub,avg);
System.out.println("Enter hostel name");
String hname=in.readLine();
System.out.println("Enter hostel location");
String loc=in.readLine();
System.out.println("Enter no of rooms");
int no=Integer.parseInt(in.readLine());
s.readData(hname,loc,no);
System.out.println("Enter Department Details");
s.showData();
System.out.println("Student Details");
s.displayData();
System.out.println("Hostel Details");
s.printData();
}
catch(Exception e){}
}
}

