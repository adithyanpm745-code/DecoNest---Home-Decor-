import java.io.DataInputStream;
class LargeSmall{
public static void main(String args[])
{

try{
DataInputStream in=new DataInputStream(System.in);
System.out.println("Enter the no of elements:");
int n=Integer.parseInt(in.readLine());
int a[]=new int[n];
System.out.println("Enter the elements:");
for(int i=0;i<n;i++){
a[i]=Integer.parseInt(in.readLine());
}
int big,small;
big=small=a[0];
for(int i=1;i<n;i++){
if(a[i]>big)
big=a[i];
if(a[i]<small)
small=a[i];
}
System.out.println("Biggest is:"+big+"Smallest is:"+small);
}catch(Exception e){}
}
}
