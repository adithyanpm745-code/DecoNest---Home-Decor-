/*draw a house*/
import java.awt.*;
import java.applet.*;
public class House extends Applet{
public void paint(Graphics g)
{
g.drawRect(500,300,500,350);
g.drawLine(500,300,730,150);
g.drawLine(730,150,1000,300);
g.drawRect(550,400,50,75);
g.drawRect(900,400,50,75);
g.drawRect(710,500,80,150);
}
}
