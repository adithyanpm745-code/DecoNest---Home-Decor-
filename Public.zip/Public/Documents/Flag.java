import java.applet.*;
import java.awt.*;
public class Flag extends Applet{
public void paint(Graphics g)
{ 
g.drawRect(200,150,250,50);
g.drawRect(200,200,250,50);
g.drawRect(200,250,250,50);
g.drawRect(200,300,20,150);
g.drawOval(300,200,50,50);
g.setColor(Color.orange);
g.fillRect(200,150,250,50);
g.setColor(Color.green);
g.fillRect(200,250,250,50);
g.setColor(Color.blue);
g.fillOval(300,200,50,50);
}
}
