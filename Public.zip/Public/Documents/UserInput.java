import java.applet.*;
import java.awt.*;
public class UserInput extends Applet{
TextField text1,text2,text3;
public void init(){
text1=new TextField(10);
text2=new TextField(10);
text3=new TextField(10);
add(text1);
add(text2);
add(text3);
}
public void paint(Graphics g){
String s1,s2,s3;
s1=text1.getText();
s2=text2.getText();
int x=Integer.parseInt(s1);
int y=Integer.parseInt(s2);
int z=x+y;
s3=String.valueOf(z);
text3.setText(s3);
}
}
