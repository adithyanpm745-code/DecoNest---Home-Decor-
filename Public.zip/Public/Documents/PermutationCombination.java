import pack.FactorialFact;
import java.io.DataInputStream;
class PermutationCombination{
public static void main(String args[]){
try{
DataInputStream in=new DataInputStream(System.in);
FactorialFact obj=new FactorialFact();
System.out.println("Enter N:");
int n=Integer.parseInt(in.readLine());
System.out.println("Enter R:");
int r=Integer.parseInt(in.readLine());
int p=n-r;
int num=obj.factorial(n);
int denom=obj.factorial(p);
int res=num/denom;
System.out.println("Permutation of"+n+ "and" +p+ "=" +res);
int d=obj.factorial(r);
int m=d*denom;
int result=num/m;
System.out.println("Combination of" +n+ "and" +r+ "="+result);
}catch(Exception e){}
}
}
