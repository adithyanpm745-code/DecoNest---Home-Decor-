<html>
<applet code="HumanFace.class" width=300 height=300>
</applet>
</html>
